# P32 pre-2005 warm-up and gap source investigation

Indicators now use observed history from 2002-01-01; signal evaluation starts
on 2005-01-01 as before. Native_history_coverage.csv records available warm-up
and flags insufficient observations. Warmup_signal_changes.csv records added,
removed and changed signals, without forcing agreement with old trades.

Gap_path_investigation.csv covers all 171 prior uncertain paths.
Gap_window_evidence.csv distinguishes native, M1 and S5 gaps and reports fresh
source/finer quote checks. Empty quotes in one or two pairs do not establish
a historical closure. These diagnostics do not automatically promote exits
or mix new source revisions into the frozen execution cache.

All32 current locked predicate streams are evaluated on continuous native MID
history before any position filter. Thresholds were not optimized. Compare the
original archive and EURUSD isolated streams using the reconciliation CSVs.
Full-history indicator seeds and native price revisions can cause differences
from old archives or the live rolling fetch windows. Missing observations can
hide additional signals. Recovery from observed bars is not proof of exact
original stream identity.

The four predeclared admission chronologies vary exit-interval endpoints and
simultaneous strategy order. Current nonhedging pair gates and strategy p0 are
applied before entry previews. Original rejected/blocked signals are retained.
The first native opening quote is still an entry estimate. Latency, stale checks
and actual price-bound cancellations are not recovered.

Earlier gaps and uncertain exits remain flagged. Their observed barrier is a
conditional modeling assumption; subsequent pair admissions carry uncertainty
lineage. A gap-qualified observed STOP/TARGET is not a verified first exit.

conditional_price_accounting.json contains ILLUSTRATIVE research units, using
1% closed-balance risk budgets (.75% EURJPY M15 short) and worst-bound price R.
It assumes static quote/home conversion and fractional size, with no margin,
live NAV sizing, financing or unrealized equity. STOP_FIRST/TARGET_FIRST values
refer only to ambiguous same-S5 barriers. These scenarios are not return bounds.
Unpriced exits suppress whole-cohort accounting. Open positions are not forced
closed. Its CAGR/DD fields are conditional CLOSED-equity estimates, not actual
broker returns or validated portfolio metrics. No best scenario is selected.

The full native source archive is at /sources.zip. Keep it or the persistent
volume for reproduction. This report includes source hashes and every raw
qualification witness. Upload the results ZIP for review; source archive can be
requested separately if a source discrepancy requires it.

No trading service was modified or contacted, and no orders can be submitted.
